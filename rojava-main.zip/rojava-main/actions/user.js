"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { requireAdmin, requireSuperAdmin } from "@/lib/auth-utils";

// Get user by ID
export async function getUserById(id) {
  try {
    const user = await prisma.user.findUnique({
      where: { id },
      include: {
        posts: {
          orderBy: { createdAt: "desc" },
        },
        _count: {
          select: {
            posts: true,
            accounts: true,
            sessions: true,
          },
        },
      },
    });

    if (!user) {
      return { error: "User not found" };
    }

    return { user };
  } catch (error) {
    console.error("Error fetching user:", error);
    return { error: "Failed to fetch user" };
  }
}

// Get user by email
export async function getUserByEmail(email) {
  try {
    const user = await prisma.user.findUnique({
      where: { email },
      include: {
        posts: {
          orderBy: { createdAt: "desc" },
        },
      },
    });

    if (!user) {
      return { error: "User not found" };
    }

    return { user };
  } catch (error) {
    console.error("Error fetching user:", error);
    return { error: "Failed to fetch user" };
  }
}

// Get all users with pagination
export async function getUsers(page = 1, limit = 10) {
  try {
    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        include: {
          _count: {
            select: {
              posts: true,
            },
          },
        },
      }),
      prisma.user.count(),
    ]);

    return {
      users,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  } catch (error) {
    console.error("Error fetching users:", error);
    return { error: "Failed to fetch users" };
  }
}

// Create user
export async function createUser(data) {
  try {
    // Only admins can create users
    await requireAdmin();

    const existingUser = await prisma.user.findUnique({
      where: { email: data.email },
    });

    if (existingUser) {
      return { error: "User with this email already exists" };
    }

    const user = await prisma.user.create({
      data: {
        email: data.email,
        name: data.name,
        fullName: data.fullName,
        image: data.image,
        role: data.role || "STANDARD",
      },
    });

    revalidatePath("/users");
    return { user };
  } catch (error) {
    console.error("Error creating user:", error);
    return { error: "Failed to create user" };
  }
}

// Update user
export async function updateUser(id, data) {
  try {
    // Only admins can update users
    await requireAdmin();

    // Check if email is being changed and if it's already taken
    if (data.email) {
      const existingUser = await prisma.user.findFirst({
        where: {
          email: data.email,
          NOT: { id },
        },
      });

      if (existingUser) {
        return { error: "Email already in use" };
      }
    }

    const user = await prisma.user.update({
      where: { id },
      data,
    });

    revalidatePath("/users");
    revalidatePath(`/users/${id}`);
    return { user };
  } catch (error) {
    console.error("Error updating user:", error);
    return { error: "Failed to update user" };
  }
}

// Delete user
export async function deleteUser(id) {
  try {
    // Only admins can delete users
    await requireAdmin();

    await prisma.user.delete({
      where: { id },
    });

    revalidatePath("/users");
    return { success: true };
  } catch (error) {
    console.error("Error deleting user:", error);
    return { error: "Failed to delete user" };
  }
}

// Update user role (admin function)
export async function updateUserRole(id, role) {
  try {
    // Only super admins can change user roles
    await requireSuperAdmin();

    const user = await prisma.user.update({
      where: { id },
      data: { role },
    });

    revalidatePath("/users");
    revalidatePath(`/users/${id}`);
    return { user };
  } catch (error) {
    console.error("Error updating user role:", error);
    return { error: "Failed to update user role" };
  }
}

// Search users
export async function searchUsers(query) {
  try {
    const users = await prisma.user.findMany({
      where: {
        OR: [
          { email: { contains: query, mode: "insensitive" } },
          { name: { contains: query, mode: "insensitive" } },
          { fullName: { contains: query, mode: "insensitive" } },
        ],
      },
      take: 10,
      include: {
        _count: {
          select: {
            posts: true,
          },
        },
      },
    });

    return { users };
  } catch (error) {
    console.error("Error searching users:", error);
    return { error: "Failed to search users" };
  }
}
