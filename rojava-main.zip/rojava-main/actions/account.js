"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import {
  requireAdmin,
  getCurrentUser,
  canModifyResource,
} from "@/lib/auth-utils";

// Get account by ID
export async function getAccountById(id) {
  try {
    const account = await prisma.account.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
            role: true,
          },
        },
      },
    });

    if (!account) {
      return { error: "Account not found" };
    }

    return { account };
  } catch (error) {
    console.error("Error fetching account:", error);
    return { error: "Failed to fetch account" };
  }
}

// Get all accounts for a user
export async function getUserAccounts(userId) {
  try {
    const accounts = await prisma.account.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
    });

    return { accounts };
  } catch (error) {
    console.error("Error fetching user accounts:", error);
    return { error: "Failed to fetch user accounts" };
  }
}

// Get account by provider
export async function getAccountByProvider(userId, providerId) {
  try {
    const account = await prisma.account.findFirst({
      where: {
        userId,
        providerId,
      },
    });

    if (!account) {
      return { error: "Account not found" };
    }

    return { account };
  } catch (error) {
    console.error("Error fetching account by provider:", error);
    return { error: "Failed to fetch account" };
  }
}

// Create account (typically handled by auth system)
export async function createAccount(data) {
  try {
    // Only admins can manually create accounts
    await requireAdmin();

    const account = await prisma.account.create({
      data,
    });

    revalidatePath("/accounts");
    revalidatePath(`/users/${data.userId}`);
    return { account };
  } catch (error) {
    console.error("Error creating account:", error);
    return { error: "Failed to create account" };
  }
}

// Update account tokens
export async function updateAccountTokens(id, data) {
  try {
    // Get the account to check ownership
    const existingAccount = await prisma.account.findUnique({
      where: { id },
      select: { userId: true },
    });

    if (!existingAccount) {
      return { error: "Account not found" };
    }

    // Only the account owner or admins can update tokens
    const canModify = await canModifyResource(existingAccount.userId);
    if (!canModify) {
      return {
        error:
          "Unauthorized: You can only update your own account or must be an admin",
      };
    }

    const account = await prisma.account.update({
      where: { id },
      data,
    });

    return { account };
  } catch (error) {
    console.error("Error updating account tokens:", error);
    return { error: "Failed to update account tokens" };
  }
}

// Delete account
export async function deleteAccount(id) {
  try {
    const account = await prisma.account.findUnique({
      where: { id },
      select: { userId: true },
    });

    if (!account) {
      return { error: "Account not found" };
    }

    // Only the account owner or admins can delete accounts
    const canModify = await canModifyResource(account.userId);
    if (!canModify) {
      return {
        error:
          "Unauthorized: You can only delete your own account or must be an admin",
      };
    }

    await prisma.account.delete({
      where: { id },
    });

    revalidatePath("/accounts");
    revalidatePath(`/users/${account.userId}`);
    return { success: true };
  } catch (error) {
    console.error("Error deleting account:", error);
    return { error: "Failed to delete account" };
  }
}

// Delete all accounts for a user
export async function deleteAllUserAccounts(userId) {
  try {
    // Only admins can delete all user accounts
    await requireAdmin();

    await prisma.account.deleteMany({
      where: { userId },
    });

    revalidatePath("/accounts");
    revalidatePath(`/users/${userId}`);
    return { success: true };
  } catch (error) {
    console.error("Error deleting all user accounts:", error);
    return { error: "Failed to delete all accounts" };
  }
}

// Check if user has specific provider linked
export async function hasProviderLinked(userId, providerId) {
  try {
    const account = await prisma.account.findFirst({
      where: {
        userId,
        providerId,
      },
    });

    return { hasProvider: !!account };
  } catch (error) {
    console.error("Error checking provider:", error);
    return { error: "Failed to check provider" };
  }
}

// Get all linked providers for a user
export async function getUserProviders(userId) {
  try {
    const accounts = await prisma.account.findMany({
      where: { userId },
      select: {
        id: true,
        providerId: true,
        createdAt: true,
      },
    });

    const providers = accounts.map((account) => ({
      id: account.id,
      provider: account.providerId,
      linkedAt: account.createdAt,
    }));

    return { providers };
  } catch (error) {
    console.error("Error fetching user providers:", error);
    return { error: "Failed to fetch user providers" };
  }
}
