"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import {
  requireAdmin,
  getCurrentUser,
  canModifyResource,
} from "@/lib/auth-utils";

// Get session by ID
export async function getSessionById(id) {
  try {
    const session = await prisma.session.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
            role: true,
          },
        },
      },
    });

    if (!session) {
      return { error: "Session not found" };
    }

    return { session };
  } catch (error) {
    console.error("Error fetching session:", error);
    return { error: "Failed to fetch session" };
  }
}

// Get session by token
export async function getSessionByToken(token) {
  try {
    const session = await prisma.session.findUnique({
      where: { token },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
            role: true,
          },
        },
      },
    });

    if (!session) {
      return { error: "Session not found" };
    }

    // Check if session is expired
    if (session.expiresAt < new Date()) {
      return { error: "Session expired" };
    }

    return { session };
  } catch (error) {
    console.error("Error fetching session:", error);
    return { error: "Failed to fetch session" };
  }
}

// Get all sessions for a user
export async function getUserSessions(userId) {
  try {
    const sessions = await prisma.session.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
    });

    return { sessions };
  } catch (error) {
    console.error("Error fetching user sessions:", error);
    return { error: "Failed to fetch user sessions" };
  }
}

// Get active sessions for a user
export async function getActiveSessions(userId) {
  try {
    const sessions = await prisma.session.findMany({
      where: {
        userId,
        expiresAt: {
          gt: new Date(),
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return { sessions };
  } catch (error) {
    console.error("Error fetching active sessions:", error);
    return { error: "Failed to fetch active sessions" };
  }
}

// Delete session (logout)
export async function deleteSession(id) {
  try {
    const session = await prisma.session.findUnique({
      where: { id },
      select: { userId: true },
    });

    if (!session) {
      return { error: "Session not found" };
    }

    // Only the session owner or admins can delete sessions
    const canModify = await canModifyResource(session.userId);
    if (!canModify) {
      return {
        error:
          "Unauthorized: You can only delete your own sessions or must be an admin",
      };
    }

    await prisma.session.delete({
      where: { id },
    });

    revalidatePath("/sessions");
    return { success: true };
  } catch (error) {
    console.error("Error deleting session:", error);
    return { error: "Failed to delete session" };
  }
}

// Delete session by token
export async function deleteSessionByToken(token) {
  try {
    await prisma.session.delete({
      where: { token },
    });

    revalidatePath("/sessions");
    return { success: true };
  } catch (error) {
    console.error("Error deleting session:", error);
    return { error: "Failed to delete session" };
  }
}

// Delete all sessions for a user (logout all devices)
export async function deleteAllUserSessions(userId) {
  try {
    // Only the user themselves or admins can delete all sessions
    const canModify = await canModifyResource(userId);
    if (!canModify) {
      return {
        error:
          "Unauthorized: You can only delete your own sessions or must be an admin",
      };
    }

    await prisma.session.deleteMany({
      where: { userId },
    });

    revalidatePath("/sessions");
    return { success: true };
  } catch (error) {
    console.error("Error deleting all user sessions:", error);
    return { error: "Failed to delete all sessions" };
  }
}

// Delete expired sessions (cleanup utility)
export async function deleteExpiredSessions() {
  try {
    // Only admins can run cleanup operations
    await requireAdmin();

    const result = await prisma.session.deleteMany({
      where: {
        expiresAt: {
          lt: new Date(),
        },
      },
    });

    revalidatePath("/sessions");
    return { success: true, deleted: result.count };
  } catch (error) {
    console.error("Error deleting expired sessions:", error);
    return { error: "Failed to delete expired sessions" };
  }
}

// Create session (typically handled by auth, but available if needed)
export async function createSession(data) {
  try {
    // Only admins can manually create sessions
    await requireAdmin();

    const session = await prisma.session.create({
      data: {
        userId: data.userId,
        token: data.token,
        expiresAt: data.expiresAt,
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
      },
    });

    revalidatePath("/sessions");
    return { session };
  } catch (error) {
    console.error("Error creating session:", error);
    return { error: "Failed to create session" };
  }
}

// Update session expiry
export async function extendSession(id, expiresAt) {
  try {
    // Get the session to check ownership
    const existingSession = await prisma.session.findUnique({
      where: { id },
      select: { userId: true },
    });

    if (!existingSession) {
      return { error: "Session not found" };
    }

    // Only the session owner or admins can extend sessions
    const canModify = await canModifyResource(existingSession.userId);
    if (!canModify) {
      return {
        error:
          "Unauthorized: You can only extend your own sessions or must be an admin",
      };
    }

    const session = await prisma.session.update({
      where: { id },
      data: { expiresAt },
    });

    return { session };
  } catch (error) {
    console.error("Error extending session:", error);
    return { error: "Failed to extend session" };
  }
}
