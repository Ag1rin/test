"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import {
  requireAdmin,
  getCurrentUser,
  canModifyResource,
} from "@/lib/auth-utils";

// Get post by ID
export async function getPostById(id) {
  try {
    const post = await prisma.post.findUnique({
      where: { id },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
            role: true,
          },
        },
      },
    });

    if (!post) {
      return { error: "Post not found" };
    }

    return { post };
  } catch (error) {
    console.error("Error fetching post:", error);
    return { error: "Failed to fetch post" };
  }
}

// Get all posts with pagination and filters
export async function getPosts(options = {}) {
  try {
    const { page = 1, limit = 10, published, authorId } = options;
    const skip = (page - 1) * limit;

    const where = {};
    if (published !== undefined) {
      where.published = published;
    }
    if (authorId) {
      where.authorId = authorId;
    }

    const [posts, total] = await Promise.all([
      prisma.post.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        include: {
          author: {
            select: {
              id: true,
              name: true,
              fullName: true,
              email: true,
              image: true,
            },
          },
        },
      }),
      prisma.post.count({ where }),
    ]);

    return {
      posts,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  } catch (error) {
    console.error("Error fetching posts:", error);
    return { error: "Failed to fetch posts" };
  }
}

// Get published posts (public)
export async function getPublishedPosts(page = 1, limit = 10) {
  return getPosts({ page, limit, published: true });
}

// Get posts by author
export async function getPostsByAuthor(authorId, page = 1, limit = 10) {
  return getPosts({ page, limit, authorId });
}

// Create post
export async function createPost(data) {
  try {
    // Only admins can create posts
    await requireAdmin();

    // Verify author exists
    const author = await prisma.user.findUnique({
      where: { id: data.authorId },
    });

    if (!author) {
      return { error: "Author not found" };
    }

    const post = await prisma.post.create({
      data: {
        title: data.title,
        content: data.content,
        mideaUrl: data.mideaUrl,
        published: data.published || false,
        authorId: data.authorId,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
          },
        },
      },
    });

    revalidatePath("/posts");
    revalidatePath(`/users/${data.authorId}`);
    return { post };
  } catch (error) {
    console.error("Error creating post:", error);
    return { error: "Failed to create post" };
  }
}

// Update post
export async function updatePost(id, data) {
  try {
    // Get the post to check ownership
    const existingPost = await prisma.post.findUnique({
      where: { id },
      select: { authorId: true },
    });

    if (!existingPost) {
      return { error: "Post not found" };
    }

    // Only the author or admins can update posts
    const canModify = await canModifyResource(existingPost.authorId);
    if (!canModify) {
      return {
        error:
          "Unauthorized: You can only edit your own posts or must be an admin",
      };
    }

    const post = await prisma.post.update({
      where: { id },
      data,
      include: {
        author: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
          },
        },
      },
    });

    revalidatePath("/posts");
    revalidatePath(`/posts/${id}`);
    revalidatePath(`/users/${post.authorId}`);
    return { post };
  } catch (error) {
    console.error("Error updating post:", error);
    return { error: "Failed to update post" };
  }
}

// Delete post
export async function deletePost(id) {
  try {
    const post = await prisma.post.findUnique({
      where: { id },
      select: { authorId: true },
    });

    if (!post) {
      return { error: "Post not found" };
    }

    // Only the author or admins can delete posts
    const canModify = await canModifyResource(post.authorId);
    if (!canModify) {
      return {
        error:
          "Unauthorized: You can only delete your own posts or must be an admin",
      };
    }

    await prisma.post.delete({
      where: { id },
    });

    revalidatePath("/posts");
    revalidatePath(`/users/${post.authorId}`);
    return { success: true };
  } catch (error) {
    console.error("Error deleting post:", error);
    return { error: "Failed to delete post" };
  }
}

// Publish post
export async function publishPost(id) {
  try {
    // Only admins can publish posts
    await requireAdmin();

    const post = await prisma.post.update({
      where: { id },
      data: { published: true },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
          },
        },
      },
    });

    revalidatePath("/posts");
    revalidatePath(`/posts/${id}`);
    return { post };
  } catch (error) {
    console.error("Error publishing post:", error);
    return { error: "Failed to publish post" };
  }
}

// Unpublish post
export async function unpublishPost(id) {
  try {
    // Only admins can unpublish posts
    await requireAdmin();

    const post = await prisma.post.update({
      where: { id },
      data: { published: false },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
          },
        },
      },
    });

    revalidatePath("/posts");
    revalidatePath(`/posts/${id}`);
    return { post };
  } catch (error) {
    console.error("Error unpublishing post:", error);
    return { error: "Failed to unpublish post" };
  }
}

// Search posts
export async function searchPosts(query, publishedOnly = false) {
  try {
    const where = {
      OR: [
        { title: { contains: query, mode: "insensitive" } },
        { content: { contains: query, mode: "insensitive" } },
      ],
    };

    if (publishedOnly) {
      where.published = true;
    }

    const posts = await prisma.post.findMany({
      where,
      take: 20,
      orderBy: { createdAt: "desc" },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            fullName: true,
            email: true,
            image: true,
          },
        },
      },
    });

    return { posts };
  } catch (error) {
    console.error("Error searching posts:", error);
    return { error: "Failed to search posts" };
  }
}
